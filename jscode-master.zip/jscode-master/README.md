# JSCode by nakorndev

A sandbox for new learner of Web JavaScript to getting start with `alert()` `prompt()` or `confirm()` before going to Node.js. Because of Node.js is hard to implement a form to receive any input from user and non-vanila code is not available.
